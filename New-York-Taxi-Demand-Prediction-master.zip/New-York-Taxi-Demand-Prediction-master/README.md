# New-York-Taxi-Demand-Prediction
In this project our task is to find number of pickups, given location coordinates(latitude and longitude) and time, in the query region and surrounding regions of New York City
